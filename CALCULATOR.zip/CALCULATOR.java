package calculator;

/**
 *
 * @author USER
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CALCULATOR implements ActionListener {
    JFrame frame;
    JTextField textfield;
    RoundedButton[] numberButtons = new RoundedButton[10];  // Use custom RoundedButton
    RoundedButton[] functionButtons = new RoundedButton[9]; // Use custom RoundedButton
    RoundedButton addButton, subButton, mulButton, divButton;
    RoundedButton decButton, equButton, delButton, clrButton, negButton;
    JPanel panel;

    // Create custom fonts for different components
    Font textFieldFont = new Font("Comic Sans MS", Font.BOLD, 30);  // Font for the text field
    Font buttonFont = new Font("Comic Sans MS", Font.BOLD, 30);    // Font for buttons

    double num1 = 0, num2 = 0, result = 0;
    char operator;

    CALCULATOR() {
        // Set up the frame
        frame = new JFrame("Fariha Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 550);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(255, 182, 193)); 
        
        ImageIcon icon = new ImageIcon(getClass().getResource("/mymelody.png"));
        frame.setIconImage(icon.getImage());

        // Set up the text field
        textfield = new JTextField();
        textfield.setBounds(50, 25, 300, 50);
        textfield.setFont(textFieldFont);
        textfield.setEditable(false);
        textfield.setBackground(new Color(255, 255, 240));  
        textfield.setForeground(Color.BLACK);  

        // Create buttons using the custom RoundedButton class
        addButton = new RoundedButton("+");
        subButton = new RoundedButton("-");
        mulButton = new RoundedButton("x");  // Changed 'x' to '*'
        divButton = new RoundedButton("÷");
        decButton = new RoundedButton(".");
        equButton = new RoundedButton("=");
        delButton = new RoundedButton("Del");
        clrButton = new RoundedButton("Clr");
        negButton = new RoundedButton("(-)");

        // Add function buttons to the array
        functionButtons[0] = addButton;
        functionButtons[1] = subButton;
        functionButtons[2] = mulButton;
        functionButtons[3] = divButton;
        functionButtons[4] = decButton;
        functionButtons[5] = equButton;
        functionButtons[6] = delButton;
        functionButtons[7] = clrButton;
        functionButtons[8] = negButton;

        // Apply custom styles to all function buttons
        for (int i = 0; i < 9; i++) {
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(buttonFont);
            functionButtons[i].setFocusable(false);
            functionButtons[i].setBackground(new Color(231, 84, 128));  
            functionButtons[i].setForeground(Color.WHITE);  // White text
        }

        // Apply custom styles to all number buttons
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new RoundedButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(buttonFont);
            numberButtons[i].setFocusable(false);
            numberButtons[i].setBackground(new Color(173, 216, 230)); 
            numberButtons[i].setForeground(new Color(121, 104, 180));  
        }

        // Set positions for specific buttons
        negButton.setBounds(50, 430, 100, 50);
        delButton.setBounds(150, 430, 100, 50);
        clrButton.setBounds(250, 430, 100, 50);

        // Create panel for number and function buttons
        panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4, 4, 10, 10));
        panel.setBackground(new Color(255, 182, 193));  // Softer pink background for the panel

        // Add number buttons and function buttons to the panel
        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addButton);
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(subButton);
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(mulButton);
        panel.add(decButton);
        panel.add(numberButtons[0]);
        panel.add(equButton);
        panel.add(divButton);

        // Add components to the frame
        frame.add(panel);
        frame.add(negButton);
        frame.add(delButton);
        frame.add(clrButton);
        frame.add(textfield);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new CALCULATOR();
    }

    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < 10; i++) {
            if (e.getSource() == numberButtons[i]) {
                textfield.setText(textfield.getText().concat(String.valueOf(i)));
            }
        }
        if (e.getSource() == decButton) {
            textfield.setText(textfield.getText().concat("."));
        }
        if (e.getSource() == addButton) {
            textfield.setText(textfield.getText().concat(" + "));
        }
        if (e.getSource() == subButton) {
            textfield.setText(textfield.getText().concat(" - "));
        }
        if (e.getSource() == mulButton) {
            textfield.setText(textfield.getText().concat(" x ")); // Changed to use '*'
        }
        if (e.getSource() == divButton) {
            textfield.setText(textfield.getText().concat(" ÷ "));
        }
        if (e.getSource() == equButton) {
            String input = textfield.getText();
            String[] tokens = input.split(" "); // Split input by spaces
            if (tokens.length == 3) { // Expecting format like "6 * 3"
                num1 = Double.parseDouble(tokens[0]);
                operator = tokens[1].charAt(0);
                num2 = Double.parseDouble(tokens[2]);

                result = switch (operator) {
                    case '+' -> num1 + num2;
                    case '-' -> num1 - num2;
                    case 'x' -> num1 * num2;
                    case '÷' -> num1 / num2;
                    default -> 0;
                };
                
                // Display result without decimal points
                textfield.setText(String.valueOf((int) result)); // Cast to int for whole number output
            }
        }
        if (e.getSource() == clrButton) {
            textfield.setText("");
        }
        if (e.getSource() == delButton) {
            String string = textfield.getText();
            textfield.setText(string.length() > 0 ? string.substring(0, string.length() - 1) : "");
        }
        if (e.getSource() == negButton) {
            double temp = Double.parseDouble(textfield.getText());
            textfield.setText(String.valueOf(-temp));
        }
    }
}

// Custom RoundedButton class for buttons with rounded corners
class RoundedButton extends JButton {
    public RoundedButton(String label) {
        super(label);
        setContentAreaFilled(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);  // Rounded corners with a radius of 30
        super.paintComponent(g2);
        g2.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);  // Border with rounded corners
    }
}

